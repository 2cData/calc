# GitLab
GitLab is a web-based DevOps lifecycle tool that provides a Git-repository manager providing wiki, issue-tracking and CI/CD pipeline features, using an open-source license, developed by GitLab Inc.

## Basic
In these basic exercise, you will learn how to use GitLab.


### Exercise One - Login to the GUI

1. Login to  https://gitlab.bcbsma.com.

2. Enter your LAN ID and the EAH password you were sent from the EAH admin team.

### Exercise Two - Setup Gitlab environment
When you are using a notebook, you must use the command line to interact with git at this time. IDE's will almost always have an interface to git as part of the application. We will learn how to use the command line because it always works and there aren't many commands. 

1. Open PuTTY

2. Enter the current edge node IP address into the Host Name Field.

3. Enter "EAH Edge Node" into the Saved Sessions field.

4. Click Save.

5. Click Open.

6. At the terminal window, enter your lan id and the EAH password you were sent from the EAH admin team.

7. Enter Git configuration information into your profile. <br />
Open your bash profile.<p/> 
```
vi ~/.bash_profile
```
Scroll to the end of the file using the down arrow. <p /> 
Enter interactive mode.<p/> 
```
:i
```
Enter your git credentials and login variables.<p />
```
git config --global http.sslVerify false
git config --global user.email "{your bcbsma email}"
git config --global user.name "{your full name}"
```

Save the code. 
```
[ESC]
:wq
```
From now on, this script will run on startup. For now, just reload.
```
source ~/.bash_profile
```

Create a workspace directory in your home directory. This is where all of your git projects will go.
```
mkdir ~/workspace
```

### Exercise Three - Clone a repo

1. Go to the EAH Bootcamp project (https://gitlab.bcbsma.com/dcalla02/eah-bootcamp) and click 'clone' dropdown.
2. Copy the link in 'Clone with HTTPS'.
3. From the terminal, navigate to your workspace folder
```
cd ~/workspace 
```
4. Run Clone command: (paste the copied link after 'git clone')

    ```
    git clone https://gitlab.bcbsma.com/{lanid}/eah-bootcamp.git
    ```
5. Clone complete.
6. Navigate to the cloned directory
```
cd eah-bootcamp/
```


### Exercise Four - Create a file and check it in

1. Create a hello world file.
```
echo "hello,world" > hello_{lan_id}.csv

```

2. Add the file to your local git repository
This command adds new, updated and deleted files to your local repository.

```
git add -A
``` 

3. Commit the change to your local git repository with a message.
```
git commit -m "Created a hello world"
``` 

4. Push the change to gitlab
So far, we have only been tracking the file locally. Now we are going to push it to the network repository. By the way, this was the killer feature of git: all other version control utilities required you to be connected to the network for all of the steps. Git only requires a network connection for merging. <p/>
It's a good practice to see how out of sync you are with the central repository before committing new files.
'''
git status
'''
Assuming no one else is working on any files that you have commits for, pushing yur code should be simple. Now is a good time to synch your local repo with the latest changes.
'''
git pull
'''
Now you can push your changes to the central repository.
'''
git push origin develop
''' 
Note that we are pushing to the develop branch rather thn the master. Typically, the master branch contains releases while the develop branch contains working code. For example, we would probably push code from develop into master at the end of the pod. If the pod was to come back for another wave, we would start puttin code in develop again. 

### Exercise Five - Modify a file and check it in
Modifying a file from the command line is just like adding a file except you can skip '''git add -A```. Gitlab also provides a web-based IDE, so we will test that. 
1. Go to the EAH Bootcamp project (https://gitlab.bcbsma.com/dcalla02/eah-bootcamp) a
2. In your repository, browse to the file you want to edit.
3. In the upper right corner of the file view, click pencil icon to open the file editor.
4. Make any changes.
5. At the bottom of the page, type a short, meaningful commit message that describes the change you made to the file.
6. Click 'Commit Changes'.

This command takes all those changes and saves them together in your local repository.

```
git commit -m 'Updated my hello world file'
```


### Exercise Six - Delete a file
You can delete a file from the command line or the web inerface. We will do it from the command line.
1. Delete the file.
```
git rm hello_{lan_id}.csv
``` 

2. Commit the change to your local git repository with a message.
```
git commit -m "Deleted hello world"
``` 

4. Push the change to gitlab
So far, we have only been tracking the file locally. Now we are going to push it to the network repository. By the way, this was the killer feature of git: all other version control utilities required you to be connected to the network for all of the steps. Git only requires a network connection for merging. <p/>
It's a good practice to see how out of sync you are with the central repository before committing new files.
'''
git status
'''
Assuming no one else is working on any files that you have commits for, pushing yur code should be simple. Now is a good time to synch your local repo with the latest changes.
'''
git pull
'''
Now you can push your changes to the central repository.
'''
git push origin develop
''' 

## Advanced

### Exercise One - Create a Repo

1. In your dashboard, click the green New project button.

2. Enter name of your project in the 'Project Name' field.
3. Add Project description (optional).
4. Project’s viewing and access rights for users can be changed at Visibility Level.
5. Select the Initialize repository with a README option, creates a README file.
6. You can clone the repository to your local system by using the git-clone command

    ```git clone http://```
7. Takes you to newly created directory

    ```cd project-name```
8. Command to create a README.md file.

    ```touch README.md```
    
9. Add the README.md file to your created directory.

    ```git add README.md```
    
10. Store the changes to the repository with a message.

    ```git commit -m "Add README"```
    
11. Push the commits to remote repository which are made on the local branch.

    ```git push -u origin master```


### Exercise Two - Add Members

1. To view, edit, add, and remove project’s members, go to project’s *Settings > Members*.

2. Type name or username of the user you want to add.
3. Select the user and the permission level to give the user.
4. Hit 'Add users to project'.


### Exercise Three - Create a branch

1. From project’s files page, choose 'New branch' from the dropdown.
2. Enter a new Branch name.

3. Click 'Create branch' 
4. Make changes to any files.
5. To merge the changes back to master you can use the widget at the top of the screen.
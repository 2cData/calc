# Hadoop
Apache Hadoop is a collection of open-source software utilities that facilitate using a network of many computers to solve problems involving massive amounts of data and computation. It provides a software framework for distributed storage and processing of big data using the MapReduce and Spark programming models.
<p />
It's a good idea to bookmark the [Hadoop command guide](https://archive.cloudera.com/cdh5/cdh/5/hadoop/hadoop-project-dist/hadoop-common/FileSystemShell.html "Hadoop Guide").

## Basic
In these basic exercises, you will learn how to interact with files stored in Hadoop from the command line.

### Exercise One - Connect to Hadoop with PuTTY
1. Open PuTTY

2. Enter the current edge node IP address into the Host Name Field.

3. Enter "EAH Edge Node" into the Saved Sessions field.

4. Click Save.

5. Click Open.

6. At the terminal window, enter your lan id and the EAH password you were sent from the EAH admin team.

7. Verify that you have access to Hadoop. <br />
```
hadoop version
```

### Exercise Two - Manage Files
1. Change to your home directory on the Edge Node. <br />
```
cd ~
```

2. Verify you are in your home directory. <br />
```
pwd
```
This should look like /home/lanid 

3. Create a sample file. <br />
```
echo "hello,world" > hello.csv
```

4. View your home directory in Hadoop. <br />
```
hdfs dfs -ls /user/{lanid}
```
This should be empty. <br />

(If your home directory is not present, you can use the /tmp/ directory. <br />
```
hdfs dfs -ls /tmp/
```
and substitute  <br />

<code>/user/{your lan id}/</code> with <code>/tmp/</code> in the following commands.)

5. Upload a file to Hadoop. <br />

```
hdfs dfs -copyFromLocal hello.csv /user/{lanid}/hello.txt
```

6. Confirm the file has been uploaded. <br />
```
hdfs dfs -ls /user/{lanid}/hello.txt
```

7. Copy the file from Hadoop to the edge node.  <br />
```
hdfs dfs -copyToLocal /user/{lanid}/hello.txt hello.txt
```

8. Confirm the file has been downloaded. <br />
```
ls ~
```
You should have two files: hello.csv and hello.txt.

9. Delete files from the Edge node. <br />
```
rm ~/hello.*
ls ~
```
The files should be gone.<br />

10. Delete files from Hadoop. <br />
```
hdfs dfs -rm -skipTrash /user/{lanid}/hello.txt
hdfs dfs -ls /user/{lanid}/
```
The file should be gone.<br />

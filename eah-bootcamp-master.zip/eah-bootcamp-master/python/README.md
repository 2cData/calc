# Python
Python is an interpreted, high-level, general-purpose programming language. Python's design philosophy emphasizes code readability with its notable use of significant whitespace. Being a general purpose language, Python is used for much more than just data science projects. Uber, Pinterest, Netflix and YouTube are all written in Python, for example, so there is a huge user community. <p />

There are two different categories of platform to code Python in; IDE's and notebooks. IDE's are installed on the client and are therefore able to bring more compute power to the user experience. Autocompletion of functions, for example, is a notable feature of IDEs. Notebooks are installed on the server. This means that no installation is needed on the client and there is tight integration with the server environment. Notebooks are very effective for sharing visualizations for this reason. Another big difference between the two is the nature of how the files are structured. IDEs create simple python files while notebooks genrate a substantial amount of xml for presentation purposes.<p /> 

As a best practice, data processing tasks are best done in a simple python script preferable built in an IDE. Analytics work is best done in a notebook to take advantage of the visualization capabilities. There is no need for an interactive presentation of a monthly data extract. Since this kind of work is typically something that can be scheduled, like a monthly extract from the Data Warehouse, it makes sense to keep them separate from more interactive models. Data science work can then be done using the interactive Notebooks, which trade ease of use for stability.<p />

At a very high level, python files will be used to manage data while notebooks will be used for analytics. Data is meant to reside on S3. Data has two phases: experimental and governed. Take the lifecycle of SDOH as an example. This was a file on an analyst's W: drive when it was first used, but it proved to be of significant enough value that it was referred over to the Data Review Team. The process for governed data is that it lands on a single NAS location and is ingested into S3 using the Common Ingestion Framework, which stores the metadata in Cloudera Director. <p/ >

Finally, the standard file format we'll use is Parquet, an open source file format for Hadoop. Parquet stores nested data structures in a flat columnar format. Compared to a traditional approach where data is stored in row-oriented approach, parquet is more efficient in terms of storage and performance.

## Basic
The basic python exersizes verify your environment is ready for use. We will not be using any notebook or IDE: the command line is sufficient.

### Exercise One - Setup python environment
1. Open PuTTY

2. Enter the current edge node IP address into the Host Name Field.

3. Enter "EAH Edge Node" into the Saved Sessions field.

4. Click Save.

5. Click Open.

6. At the terminal window, enter your lan id and the EAH password you were sent from the EAH admin team.

7. Verify that you have access to Python3. <br />
```python --version```<p />
This should return Python 2.7.5. Cloudera requires Python 2, but we are developing in Python 3. You need to update your bash_profile to create an alias for python 3.<p />
<code>vi ~/.bash_profile</code> <p />
Scroll to the end of the file using the down arrow. <p /> 
Enter interactive mode. <code>:i</code><p />
Enter the alias. <code>alias py36=/opt/cloudera/parcels/Anaconda/envs/py36/bin/python</code><p /> 
Save the code. <code>:wq</code><p />
From now on, this script will run on startup. For now, just reload.<code>source ~/.bash_profile</code><p/>
Now you can launch Python 3.6 from the command line. <p />
<code>py36 --version</code><p />
This should return Python 3.6.8 :: Anaconda custom (64-bit)

### Authenticate
There are two different LDAP networks at BCBSMA: the on-premise and the EAH network. Security does not allow them to be automatically synchronized. For that reason, you need to refresh your authentication every 24 hours.<p />
<code>kinit</code> 

### Check environment

1.  A quick sanity check of your environment to make sure your packages are installed and available is a good first step. 
<code>python python/checkImports.py</code>

### Work with objects in S3
The standard for working with data in EAH is Spark. However, we'll just look at how it works in Pandas since we don't get into Spark until the PySpark sessions.<p />
1. Import S3 libraries
These first three lines never change.<p /> 
```python
import boto3
client = boto3.client('s3')
resource = boto3.resource('s3')
```

2. Configure the bucket and key.
The bucket in S3 is a unique identifier. Just think of it as a top-level folder.<br />
The key in this use case is the path to a file.<p />
```python
obj = client.get_object(Bucket='bcbsma-analytics-prod-raw', Key='staging/Exclusion_NDCs.csv')
```

3. Read a file from S3
Reading a file from S3 as a csv means that you need to skip all of the S3 header information
(versioning, location, etc). You just want the Body of the object.<p />
```python
import pandas as pd
csv = pd.read_csv(obj['Body'])
csv.count()
```

4. Write a file to S3
An object can be anything, but in our case it's just a String.<p />
```python
from io import StringIO
```

Have pandas stream out its contents into the String buffer as a csv file.<p /> 
```python
csv_buffer = StringIO()
csv.to_csv(csv_buffer)
```

Write the contents of the buffer into an S3 object.<p />
```python
s3_resource = boto3.resource('s3')
s3_resource.Object('bcbsma-analytics-prod-raw', 'df.csv').put(Body=csv_buffer.getvalue())
```

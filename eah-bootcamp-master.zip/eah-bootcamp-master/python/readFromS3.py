# These first three lines never change. 
import boto3
client = boto3.client('s3')
resource = boto3.resource('s3')

# The bucket in S3 is a unique identifier. Just think of it as a top-level folder
# The key in this use case is the path to a file
obj = client.get_object(Bucket='bcbsma-analytics-prod-raw', Key='staging/Exclusion_NDCs.csv')

# Reading a file from S3 as a csv means that you need to skip all of the S3 header information
# (versioning, location, etc). You just want the Body of the object.
import pandas as pd
csv = pd.read_csv(obj['Body'])
csv.count()

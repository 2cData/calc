# An object can be anything, but in our case it;s just a String
from io import StringIO

# Have pandas stream out its contents into the String buffer as a csv file 
csv_buffer = StringIO()
csv.to_csv(csv_buffer)

# Write the contents of the buffer into an S3 object
s3_resource = boto3.resource('s3')
s3_resource.Object('bcbsma-analytics-prod-raw', 'df.csv').put(Body=csv_buffer.getvalue())

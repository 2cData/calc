# S3
S3 provides simple object storage, useful for hosting website images and videos, data analytics, and both mobile and web applications. Object storage manages data as objects, meaning all data types are stored in their native formats. You can store virtually unlimited files and files maintain a history of revisions.
<p />
It's a good idea to bookmark the [S3 command guide](https://docs.aws.amazon.com/cli/latest/reference/s3/index.html "Beeline Guide").
<p />
In S3, the Analytics team will have access to three different buckets:<p />

+ s3://bcbsma-analytics-prod-raw
   - Individual developers can upload files here for evalation. These files are not under data governance.
+ s3://bcbsma-analytics-prod-curate
   - The Common Ingestion Framework will land data from the NAS into this bucket. Analytic databases will be in the /analytics folder. For example, CDR is stored in s3://bcbsma-analytics-prod-curate/clm/edw_v_cdr  
+ s3://bcbsma-analytics-prod-prod
   - This is for operationalized data. There is no data there yet.

<p />
1. Using PuTTY, login to the edge node

## Basic
In these basic exercises, you will learn how to interact with files stored in S3 from the command line.

### Exercise One - Connect to S3 with PuTTY
1. Open PuTTY

2. Enter the current edge node IP address into the Host Name Field.

3. Enter "EAH Edge Node" into the Saved Sessions field.

4. Click Save.

5. Click Open.

6. At the terminal window, enter your lan id and the EAH password you were sent from the EAH admin team.

7. Verify that you have access to Aws. <br />
<code>aws --version</code>

### Exercise Two - Manage Files
1. Change to your home directory on the Edge Node. <br />
 ```bash
 cd ~
 ```

2. Verify you are in your home directory. <br />
 ```bash
 pwd
 ```
This should look like /home/lanid 

3. Create a sample file. <br />
 ```bash
 echo "hello,world" > hello_{lanid}.csv
 ```

4. Query the raw bucket in S3. <br />
 ```bash
 aws s3 ls s3://bcbsma-analytics-prod-raw/hello_{lanid}.txt
```
This should be empty. 

5. Upload a file to S3. <br />
 ```bash
 aws s3 cp hello_{lanid}.csv s3://bcbsma-analytics-prod-raw/hello_{lanid}.txt
 ```

6. Confirm the file has been uploaded. <br />
 ```bash
 aws s3 ls s3://bcbsma-analytics-prod-raw/hello_{lanid}.txt
 ``` 

7. Copy the file from S3 to the edge node.  <br />
 ```bash
 aws s3 cp s3://bcbsma-analytics-prod-raw/hello_{lanid}.txt hello_{lanid}.txt 
 ```

8. Confirm the file has been downloaded. <br />
 ```bash
 ls hello_{lanid}.*
 ```
You should have two files: hello.csv and hello.txt.

9. Delete files from the Edge node. <br />
 ```bash
 rm ~/hello_{lanid}.*
 ```
 ```bash
 ls ~
 ```
The files should be gone.<br />

10. Delete files from S3. <br />
 ```bash
 aws s3 rm s3://bcbsma-analytics-prod-raw/hello_{lanid}.txt
 ```

The file should be gone.<br />

## Advanced
In this advanced exercise, you will copy data from the network to the Edge Node using FileZilla.

### Exercise One - Connect to the Edge Node with FileZilla
We connect connect directly to S3 from your workstation because of security constraints. This process will copy a file from S3 to the edge node and then use FileZilla to copy the file from the edge node to the BCBSMA network. <p />

FileZilla is available from Software Center.

1. Change to your home directory on the Edge Node. <br />
 ```bash
 cd ~
 ```

2. Verify you are in your home directory. <br />
 ```bash
 pwd
 ```
This should look like /home/lanid 

3. Create a sample file. <br />
 ```bash
 echo "hello,world" > hello_{lanid}.csv
 ```
 5. Upload a file to S3. <br />
 ```bash
 aws s3 cp hello_{lanid}.csv s3://bcbsma-analytics-prod-raw/hello_{lanid}.txt
 ```

6. Confirm the file has been uploaded. <br />
 ```bash
 aws s3 ls s3://bcbsma-analytics-prod-raw/hello_{lanid}.txt
 ``` 

7. Copy the file from S3 to the edge node.  <br />
 ```bash
 aws s3 cp s3://bcbsma-analytics-prod-raw/hello_{lanid}.txt hello_{lanid}.txt 
 ```

8. Confirm the file has been downloaded. <br />
 ```bash
 ls hello_{lanid}.*
 ```
You should have two files: hello.csv and hello.txt.

9. Open FileZilla and enter the following information:
- Host: The IP address of the edge node
- username: your LAN id
- password: your EAH password
- port: 22
<p />
Click the Quick Connect button

10. To save this session for future use, go to File -> Copy current connection to Site Manager. Under My Sites, call this connection EAH and click OK.
# Hive
Apache Hive is a data warehouse software project built on top of Apache Hadoop for providing data query and analysis. Hive gives a SQL-like interface to query data stored in various databases and file systems that integrate with Hadoop.
<p />
It's a good idea to bookmark the [beeline command guide](https://cwiki.apache.org/confluence/display/Hive/HiveServer2+Clients#HiveServer2Clients-BeelineCommands "Beeline Guide").

1. Using PuTTY, login to the edge node

## Basic
In these basic exercises, you will learn how to query Hive using the command line tool, beeline.
Note that in the future, you will also be able to access Hive through WinSQL on the desktop.
### Exercise One - Start beeline
The first step is to verify you can run beeline and connect to Hive.
1. Using PuTTY, login to the edge node
1. Using the PuTTY connection you create in the Hadoop training, connect to the EAH Edge Node. <br />

2. Run beeline: <br />
```bash
beeline -u "jdbc:hive2://ip-10-33-1-106.bcbsmasdaws.net:10000/default;principal=hive/ip-10-33-1-106.bcbsmasdaws.net@BCBSMASDAWS.NET;ssl=true;sslTrustStore=/var/lib/cloudera-scm-agent/agent-cert/cm-auto-global_truststore.jks;trustStorePassword=wYF97V0zc7Ru4wyQVbtkd0tqG3xR27iFMR77T0t6nOj"
```

The next step is to verify you have access to the Analytics database and can query tables.
1. Change to the analytics database. <br />
<code>use analytics;</code>

2. List tables. <br />
<code>show tables;</code>

3. Run a SQL query against the V_CDR table. <br />
<code>SELECT mem_num FROM  edw_v_cdr LIMIT 1;</code>

4. Verify results.

5. Quit beeline. <br />
<code>!q</code>

### Exercise Two - Improve query performance
1. After you create or replace a table, you should compute statistics. <br />
```
ANALYZE TABLE table_name COMPUTE STATISTICS;
```

2. After a table has had its statistics computed, you can take advantage of Cost Based Optimization.
```
set hive.cbo.enable=true;
set hive.compute.query.using.stats=true;
set hive.stats.fetch.column.stats=true;
set hive.stats.fetch.partition.stats=true;
```

3. In general, vectorized execution will also yield performance gains.
```
set hive.vectorized.execution=true;
set hive.vectorized.execution.enabled = true;
```


### Exercise Three - Export results
```bash
beeline -u "jdbc:hive2://ip-10-33-1-106.bcbsmasdaws.net:10000/default;principal=hive/ip-10-33-1-106.bcbsmasdaws.net@BCBSMASDAWS.NET;ssl=true;sslTrustStore=/var/lib/cloudera-scm-agent/agent-cert/cm-auto-global_truststore.jks;trustStorePassword=wYF97V0zc7Ru4wyQVbtkd0tqG3xR27iFMR77T0t6nOj"  > cdr.out 
```
## Advanced
There are some more advanced functions that can make you more productive as you get deeper into development.


### Create a materialized view
While Hive does not have materialized views per se, you store the results of a SQL statement as a table. This can result in substantial performance gains. 

```sql
CREATE TABLE analytics.edw_v_cdr_enrollment 
ROW FORMAT SERDE 'org.apache.hadoop.hive.ql.io.parquet.serde.ParquetHiveSerDe' 
STORED AS INPUTFORMAT 'org.apache.hadoop.hive.ql.io.parquet.MapredParquetInputFormat' 
OUTPUTFORMAT 'org.apache.hadoop.hive.ql.io.parquet.MapredParquetOutputFormat' 
AS SELECT * FROM analytics.edw_v_cdr WHERE RECORD_TYPE = 'ENROLLMENT';
```
Whenever you create a table in Hive or refresh its data, you should always compute statistics. This is an easy performance optimization.

```sql
analyze table analytics.edw_v_cdr_enrollment compute statistics;
```
You may want to copy the data from Hadoop into S3. One reason may be to use non-Cloudera tools to access the data such as Athena. 
```
hadoop distcp hdfs:///user/hive/warehouse/analytics.db/edw_v_cdr_enrollment/ s3a://bcbsma-analytics-prod-raw/test/edw_v_cdr_enrollment/
```

At this point, your Hive table will still be pointing to HDFS to read the data. This may be fine. If it is not, it is possible to change the location of the underlying dataset (notice the lack of a trailing slash). You can then delete the data from hdfs and recompute statistics.
```
ALTER TABLE analytics.edw_v_cdr_enrollment SET LOCATION "s3a://bcbsma-analytics-prod-raw/test/edw_v_cdr_enrollment";
analyze table analytics.edw_v_cdr_enrollment compute statistics;
```

Exit out of beeline to delete the files from hdfs.
```
hdfs dfs -rm -r -SkipTrash /user/hive/warehouse/analytics.db/edw_v_cdr_enrollment/
```

### Create a sample dataset from a larger table
When you are doing initial exploratory work against a larger dataset, you might want to iterate faster than the time it takes to retrieve the full dataset. It's not uncommon to take a random sample of the table, say one percent. The code below shows an example of taking one percent of the CDR dataset.

```sql
CREATE TABLE analytics.edw_v_cdr_sample 
ROW FORMAT SERDE 'org.apache.hadoop.hive.ql.io.parquet.serde.ParquetHiveSerDe' 
STORED AS INPUTFORMAT 'org.apache.hadoop.hive.ql.io.parquet.MapredParquetInputFormat' 
OUTPUTFORMAT 'org.apache.hadoop.hive.ql.io.parquet.MapredParquetOutputFormat' 
AS SELECT * FROM analytics.edw_v_cdr TABLESAMPLE(1 PERCENT);
```
Whenever you create a table in Hive or refresh its data, you should always compute statistics. This is an easy performance optimization.

```sql
analyze table analytics.edw_v_cdr_sample compute statistics;
```
### Run a script
If you want to automate a Hive process, it makes sense to externalize all of the commands in a file. By convention, I use the extension .hql, but this is not manadatory. You need to use the beeline connection string, followed by <code>-f</code>, followed by the file name. For example, 
```bash
beeline -u "jdbc:hive2://ip-10-33-1-106.bcbsmasdaws.net:10000/default;principal=hive/ip-10-33-1-106.bcbsmasdaws.net@BCBSMASDAWS.NET;ssl=true;sslTrustStore=/var/lib/cloudera-scm-agent/agent-cert/cm-auto-global_truststore.jks;trustStorePassword=wYF97V0zc7Ru4wyQVbtkd0tqG3xR27iFMR77T0t6nOj" -f myquery.hql
```
You can include multiple commands using a using a semi-colon at the end of each individual command followed by a line break.

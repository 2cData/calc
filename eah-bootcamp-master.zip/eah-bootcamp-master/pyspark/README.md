# PySpark
Apache Spark is an open-source distributed general-purpose cluster-computing framework. Spark provides an interface for programming entire clusters with implicit data parallelism and fault tolerance. The biggest difference EAH brings to the table over the current SAS solution is the ability to run queries across multiple machines in a cluster. As the analytics team and workloads grow, we cn horizontally scale by adding new servers. Since EAH is on the cloud, we can size elastically as needed. <p />
PySpark is the collaboration of Apache Spark and Python. Since Python is the forward looking language of choice BCBSMA and EAH represents the new cloud-based elastic server configuration being used, PySpark is logically the language of choice for the analytics pods. <p />
Moving to Aamzon Web Services (AWS) makes it possible to store practically unlimited amounts of data on S3. We do still have to pay a premium for computer, however. Because of the discrepancy between compute and store, PySpark is the only suppoerted way of working with data on EAH. Using pandas will result in out of memory errors on the edge node, and that not only impacts your work but also the developers who share the edge node. <p />

## Basic
The basic PySpark exercises verify your environment is ready for use. We will not be using any notebook or IDE: the command line is sufficient.

### Exercise One - Setup pyspark environment
1. Open PuTTY

2. Enter the current edge node IP address into the Host Name Field.

3. Enter "EAH Edge Node" into the Saved Sessions field.

4. Click Save.

5. Click Open.

6. At the terminal window, enter your lan id and the EAH password you were sent from the EAH admin team.

7. Set environmental variables
You need to update your bash_profile to create the proper environmental variables for PySpark.<p />
<code>vi ~/.bash_profile</code> <p />
Scroll to the end of the file using the down arrow or scroll to the line below <code>PATH=$PATH:$HOME/.local/bin:$HOME/bin</code>. <p /> 
Enter interactive mode. ```:i```<p />
```
export PYSPARK_PYTHON=/opt/cloudera/parcels/SPARK2/lib/spark2
export SPARK_HOME=/opt/cloudera/parcels/SPARK2/lib/spark2
export PYTHONPATH=$SPARK_HOME/python/:$PYTHONPATH
export PATH=$SPARK_HOME/bin:$PATH
export CONDA_PREFIX=/opt/cloudera/parcels/Anaconda/envs/py36
export PYSPARK_DRIVER_PYTHON=$CONDA_PREFIX'/bin/python'
export PYSPARK_PYTHON=$CONDA_PREFIX'/bin/python'
export PATH

alias pyspark2="pyspark2 --jars /usr/lib/nz/nz-connector.jar"
```

Save the code. 
```
[ESC]
:wq
```

From now on, this script will run on startup. For now, just reload.<code>source ~/.bash_profile</code><p/>

7. Run pyspark. <p />
```pyspark2```
And you should see Spark 2.x and Python 3.x

```
Welcome to
      ____              __
     / __/__  ___ _____/ /__
    _\ \/ _ \/ _ `/ __/  '_/
   /__ / .__/\_,_/_/ /_/\_\   version 2.3.0.cloudera2
      /_/

Using Python version 3.6.8 (default, Dec 30 2018 01:22:34)
SparkSession available as 'spark'.
```

### Authenticate
There are two different LDAP networks at BCBSMA: the on-premise and the EAH network. Security does not allow them to be automatically synchronized. For that reason, you need to refresh your authentication every 24 hours.<p />
```kinit```
This must be done through the Jupyter terminal, not PuTTY.

### Use data from S3
We will create a simple dataframe from a file stored in S3. 

1. Set up standard imports
```python
from pyspark import SparkContext
from pyspark.sql import SparkSession, SQLContext
```
2. Create a spark session (note that we will be closing this later) 
```python
 spark = SparkSession.builder.appName("Hello World {landid}").getOrCreate()
```
3. Read a directory in from S3 and expose it as a temp table
```python
df = spark.read.parquet('s3a://bcbsma-analytics-prod-publish/cns/edw_v_mem_mth_exp/').createOrReplaceTempView("v_mem_mth_exp")
```
As you can see, this is actually easier than reading from S3 using pandas and it keeps SQL as a constant language construct. And notice how we created a temp table out of the dataframe.
We are pointing to a directory that contains a large number of parquet files. This is standard for data that is ingested from sqoop or CIF.

4. Read data from the dataframe as if it was a sql statement
```python
df = spark.sql("select count(1) from v_mem_mth_exp").show()
```
Because we created a temp table out of the csv file, we can query that csv file with normal SQL statements.

5. Always stop your session. Otherwise, the resources are not released.
```python
spark.stop()
```

### Use data from Hive
Since spark runs on the Hadoop cluster, you don't have to do much to read from a table. Just enter a sql statement.
1. Set up standard imports
```python
from pyspark import SparkContext
from pyspark.sql import SparkSession, SQLContext
```
2. Create a spark session (note that we will be closing this later) 
Because this is a bigger query, it makes sense to size this job

We have 8 workers with 14 cores each and ~75 GB. 8 * 14 = 112. In spark, I want to make sure that i parallize this job as much as possible (Spark runs better wide than tall, as oposed to relational databases that just want one big machine). 2 cores x 55 executors would be close to the "max" configuration. 
```python
spark.stop()
spark.sparkContext.stop()        
spark = SparkSession \
        .builder \
        .appName("executor") \
        .config("spark.executor.memory", "48G") \
        .config("spark.executor.cores", "5") \
        .config("spark.executor.instances", "2") \
        .getOrCreate()  
   
```
3. Read a table from hive
```python
df = spark.sql("SELECT mem_num FROM analytics.edw_v_cdr LIMIT 10").show()
```
This is an actual query taken from the Medicare AgeIn pod (with the paramters in the where clause shorted to one month)

5. You can see how your job is running on the cluster. 
Bookmark this page: [Spark](https://10.33.0.82:8090/cluster/apps "Spark Jobs").

6. Always stop your session. Otherwise, the resources are not released.
'''
spark.stop()
'''

### Use data from Neteeza
Reading data from Neteeza is not a best practice, but not all of the data we need has been moved over yet.
1. Set up standard imports
```python
from pyspark import SparkContext
from pyspark.sql import SparkSession, SQLContext
```

2. Create a spark session (note that we will be closing this later) 
```python
sparkSession = SparkSession \
        .builder \
        .appName("Hello Neteeza {landid}") \
        .getOrCreate()
```
3. Prepare to time the job. 
```python
from timeit import default_timer as timer
```
4. Get the network login information. This was not needed for Hiev but is needed for odbc.
```python
import getpass

uid =  getpass.getuser()
pwd = getpass.getpass("Enter LAN pwd: ") 
```

5. Read data from Neteeza

```python
start = timer()
df = sparkSession \
        .read \
        .format("jdbc") \
        .option("url", "jdbc:netezza://bntzp01z.bcbsma.com:5480/PDWAPPRP") \
        .option("user", uid) \
        .option("password", pwd) \
        .option("driver", "org.netezza.Driver") \    
        .option("dbtable", "(SELECT * FROM V_MEM_MTH_EXP LIMIT 10) as a") \
        .load() 
end = timer()
print(end - start) 
print(df.count())
```
6. Always stop your session. Otherwise, the resources are not released.
```python
spark.stop()
```
## Advanced
There are some more advanced functions that can make you more productive as you get deeper into development.

### Store dataframes for future use
In SAS, it was very common to create temporary tables. In this environment it makes sense to save these tables to S3. It optimizes the speed of your pipleline because its faster to read parquet than it it to do a full table scan.

```python
from pyspark import SparkContext
from pyspark.sql import SparkSession, SQLContext

spark.stop()
spark.sparkContext.stop()        
spark = SparkSession \
        .builder \
        .appName("executor") \
        .config("spark.executor.memory", "48G") \
        .config("spark.executor.cores", "5") \
        .config("spark.executor.instances", "2") \
        .getOrCreate()
        
df = spark.sql("SELECT * FROM analytics.edw_v_cdr TABLESAMPLE(1 PERCENT)")
df.cache()
df.repartition(1)
df.write.mode("overwrite").option("header", "true").parquet("s3a://bcbsma-analytics-prod-raw/MyTable/")
```
Storing data in S3 will substantially increase performance over continuing to work with the dataframe in memory. Also, you will be able to access the data again without having to redo the work. An even more performant way of access the dataset is to create a Hive table that reads the parquet files store in S3.
```python
df.write.saveAsTable("analytics.MyTable")
```
This will create a Hive external table that will read the parquet data from the S3 directory. The advantage to using Hive over S3 instead of just querying S3 is the additional query optimization that Hive will do. Like all databases, Hive takes your sql statement and converts it into a logical plan and then a physical plan, making optimizations along the way. For the curious, you can see how a query might actually be run. This can help you optimize complex queries.
```python
df.explain(True)
```

### Manually kill a Spark job
We are working in a shared environment. For the most part, eveyone closes their spark session when they are done. 
```python
spark.stop()
```
Sometimes, it doesn't work out that way. Your Jupyter Notebook might crash, you might forget, etc. You can kill your spark job manually. The first step is to view all of the running spark jobs here: https://10.33.0.82:8090/cluster/apps/RUNNING. Look for your lanid to find your application id in the ID column. Copy and paste into the following statement: 

```
yarn application -kill {your application id}
```
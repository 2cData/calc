# EAH Bootcamp
The Enterprise Analytics Hub is a suite of tools to enable advanced and predictive analytics. It is a distinct environment from the Operational Data Hub and the Data Warehouse.

The purpose of the bootcamp is to get hands-on experience using each of the tools. When you first go through the bootcamp, the following order is recommended: <p />
1. S3
2. Hadoop
3. Hive
4. Python
5. PySpark
6. Gitlab

Once you have comppleted the bootcamp, come back to re-take individual lessons as a refresher as needed. <p />
If you subscribe to this repo, you'll be notified when additional topics are added.
<p />

The rest of this document gives a high-level overview of the major components: <p />
1. Platform
2. Data Platform
3. Compute Platform

Note, in order to complete this bootcamp, you will need access to the following:
1. Confluence
2. Gitlab
3. EAH

Access requests can be made through the [MSO Kanban Board](https://bcbsma.atlassian.net/secure/RapidBoard.jspa?rapidView=551 "MSO Kanban Board").

## Platform
Most users will draw a comparison between running with Python running in the cloud. 

### Edge node
In order to access EAH, users will login to the edge node. Edge nodes are the interface between the Hadoop cluster and the outside network (AWS and Cloudera). Most commonly, edge nodes are used to run client applications and cluster administration tools. There is a single edge node, so all users running on that edge node are competing for scarce resources. For this reason, we prefer to push as much of our operations to the cluster as we can.

Edge nodes are Linux machines, which means you need to use PuTTY to login to the edge node and interact with the edge node through the Linux command line. Luckily, there really isn't much you need to do on the command line so you don't need to learn Linux. We will specifically cover the commands you need to use.

### PuTTY
If PuTTY is not installed on your machine, go to Service Now and install PuTTY Prod. For some people, it gets pushed to their machine automatically. For others, they get pinged from Tech Support who takes over your computer and does the install. 

### Gitlab
Of all the technologies introduced here, source code control is the most important. Moving code off of the desktop and onto a version-controlled network application is a critical component of business continuity. In each pod, we had an issue where code was not checked in and then was lost or made unavailable when people leave. Check in as frequently as you would save a document in Word. There is no reason to not check in work, finished or not. Unlike software development, we will not be creating multiple branches and creating pull requests at this time because there is just a lot less overlap on specific files with data scientists.

## Data Platform

Most users will draw a comparison between Neteeza and the data platform. EAH will use tables exported from the Data Warehouse, typically refreshed monthly. Unlike in Neteeza, this data can be archived for longer storage affordably. Also, the data platform can house semi-structured and unstructured data. For example, storing the actual call center recordings in addition to just the metadata is a good use of S3.   

### Amazon S3 (Simple Server Storage)
S3 is the standard location for storing all data for EAH. Typically, data will be landed in a NAS location in the network. For example, every month the Neteeza team exports V_CDR to a NAS location. The Common Ingestion Framework consumes this file and stores it in S3. A Hive table reads the data from this S3 location. You can then create a Spark dataframe in Python that reads data from the Hive table. Python can also use spark to read in csv and parquet files directly from S3 into a dataframe as well as storing the output from a dataframe in S3.

### Hive
While S3 can store any data as an object, it can be convenient to query structured data as if it were a table in Neteeza or Oracle. Cloudera Hive can create an external table that uses S3 as a data source while providing schema information, like column names and datatypes. CDR, for example, will usually be queried from Hive as opposed to the underlying parquet files for convenience. There are too many column names to easily remember, so its worth the extra effort.

## Compute Platform

Most users will draw a comparison between SAS running on their laptop with Python running in the cloud. 

### Python
There is a push to move from SAS to Python at BCBSMA. Data science algorithms will be coded in Python. 

### PySpark
When processing data, you must use Spark as opposed to Pandas. Spark will distribute the query across the cluster while pandas stored the data in memory on the shared edge node.

### Other
Other refers to data science tools. For example, in Wave One we evaluated H2O. In Wave Three, we'll evaluate Cloudera Data Science Workbench. We are currently using the open source version of Jupyter Hub but this may or may not continue into the future. Various IDEs are being evaluated.



